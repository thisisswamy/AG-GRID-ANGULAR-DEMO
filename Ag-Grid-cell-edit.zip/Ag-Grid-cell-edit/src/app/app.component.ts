import { Component, OnInit } from '@angular/core';
import { GridApi } from 'ag-grid-community';
import { TableData } from 'src/TableData';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'Ag-Grid-Example';
  gridApi!: GridApi<any>;
  cols: any = [];
  months = ['USERINFO','JAN', 'FEB', 'MAR'];

  rowData: any = TableData.sampleUsersData
  correctedData:any;

  ngOnInit(): void {
    let i = 0;
    this.correctedData = this.calculateMonthlyTotals(this.months,this.rowData)
    this.months.forEach((Element, index) => {
      let parentHeader = this.getTableColumn(Element, Element, i);
      parentHeader.children = [];
      if(Element ==='USERINFO'){
        let idColumn = this.getTableColumn('id', Element, i);
        let nameColumn = this.getTableColumn('name', Element, i);
        parentHeader.children.push(idColumn);
        parentHeader.children.push(nameColumn);
      }
     else{
      let expectedColumn = this.getTableColumn('expected', Element, i);
      let committedColumn = this.getTableColumn('committed', Element, i);
      parentHeader.children.push(expectedColumn);
      parentHeader.children.push(committedColumn);
     }
      this.cols.push(parentHeader);
    });
    this.cols.push({
      headerName: 'Total',
      headerClass: 'bg-yellow',
      children:[
        {
          filed:"expected",
          headerName:'expeceted',
          headerClass: 'bg-yellow',
          valueGetter: "data['JAN']['expected'] + data['FEB']['expected'] + data['MAR']['expected']",
          cellStyle:{ "background-color": 'yellow' }
        },
        {
          filed:"committed",
          headerName:'committed',
          headerClass: 'bg-yellow',
          valueGetter: "data['JAN']['committed'] + data['FEB']['committed'] + data['MAR']['committed']",
          cellStyle:{ "background-color": 'yellow' }
        }

      ]
    });
    console.log(this.cols)
  }

  //Assign BG color object to update the color of a specific column
  bgColor: { [key: string]: string } = {
    USERINFO:'bg-blue',
    JAN: 'bg-yellow',
    FEB: 'bg-orange',
    MAR: 'bg-green',
    TOTAL: 'light-bg-blue',
  };

  
   //Generates column definition objects based on the provided parameters such as header name, month, row, and whether the column is editable
  getTableColumn(headerName: any, month: any, row: number, isEditable?:any) {
    let cssColor = this.bgColor[month].substring(3)
    let colobj: any = {
      headerName: headerName,
      field: headerName,
      headerClass: this.bgColor[month],
      width:"160px",
      //cellStyle:{ "background-color": cssColor },
      cellStyle: (params: any) => this.getCellStyle(params, headerName),
      valueGetter: (params: any) => this.getValue(params, month, row),
      //getCellClass: (params: any) => this.getCellClass(params, headerName)
    };
    if (headerName === 'committed' || headerName === 'expected') {
      colobj.editable = true; 
      // Add cell class rules for edit mode
      // colobj.cellClassRules = {
      //   'edit-highlight': (params: any) => params.node.rowPinned === undefined && params.colDef.field === headerName
      // };
    }
    return colobj;
  }

  
  getValue(params: any, months: any, row: any) {
    let data = params.data[months][params.colDef.field];
    return data;
  }

  //AG Grid component is ready. It sets up the grid with column definitions, row data, and other options
  onGridReady(event: any) {
    this.gridApi = event.api;
    // this.gridApi.setRowData(this.rowData); //These methods are deprecated || Library suggesting below format
    this.gridApi.setGridOption('rowData', this.correctedData);
    // this.gridApi.setColumnDefs(this.cols); //These methods are deprecated || Library suggesting below format 
    this.gridApi.setGridOption('columnDefs', this.cols);
    this.gridApi.setGridOption('getRowStyle', this.getRowStyle());
    // this.gridApi.setGridOption('getRowClass', this.getRowStyle());
    this.gridApi.setGridOption('onCellValueChanged', this.updtedColumns(event.api));
  }
  
  //To handle cell value changes in the grid. It updates the data accordingly and refreshes the grid
  updtedColumns(event: any) {
    return (params: any) => {
      const field = params.column.colDef.field;
        let data = params.data;
        let parentColumnIndex = params.column.getParent().groupId; // Get the parent column
        const editedFieldValue = data[field]
        const editedColumnMonth = this.months[parentColumnIndex]
        data[editedColumnMonth][field] =  +editedFieldValue
        const updatedRowData = this.updateRowData(this.correctedData,data)
        this.correctedData = this.calculateMonthlyTotals(this.months,updatedRowData)
        // Set editing flag
        data.editing = true;
        this.gridApi.applyTransaction({ update: [data] });
        this.gridApi.setGridOption('rowData', this.correctedData);
    };
  }
  
  //Calculates the total for each month and updates the data accordingly
  calculateMonthlyTotals(columnDefs:any[], rowData:any[], recalculate?:true){
    const months = columnDefs.filter((col:any) => col !== 'USERINFO');
    const newRowList = rowData.filter((item:any)=>item.USERINFO.name !== 'Total')
    let totalRow:any = {
      USERINFO: { 
        name: 'Total'
      }
    }
    months.forEach((month:any) => { 
      const monthCommittedTotal = newRowList.reduce((total:any, row:any) => total + (row[month].committed || 0), 0);
      const monthExpectedTotal = newRowList.reduce((total:any, row:any) => total + (row[month].expected || 0), 0);
      totalRow[month] = { expected: monthExpectedTotal, committed: monthCommittedTotal }
    });
    newRowList.push(totalRow);
    return newRowList;
  };

  //Cell value updates the row data with new values
  updateRowData(rowData:any, newData:any){
    const index = rowData.findIndex((item:any) => item.USERINFO.id === newData.USERINFO.id);

    if (index !== -1) {
      rowData[index] = newData;
    }
    return rowData;
  };


  // Update last row styles, background color 
  getRowStyle():any{
    // Check if the row is the last row
    return (params:any)=>{
      if (params.node.rowIndex === params.api.getDisplayedRowCount() - 1) {
        return {
          background: 'lightblue',
          fontWeight: 'bold',
          cursor:'not-allowed',
          pointerEvents:'none'

        };
      }
      return null
    }
  };

  //return the class based on the edit state
  getCellClass(params: any, headerName: string) {
    if (params.node.rowPinned === undefined && params.colDef.field === headerName && params.node.data.editing) {
      console.log("Inside Get cell class");
      return 'edit-highlight';
    }
    return null;
  }

  // getCellStyle(params: any, headerName: string) {
  //   let cellStyle: any = { "background-color": params.node.rowPinned ? 'inherit' : this.bgColor[headerName] };
    
  //   if (params.node.data.editing && params.colDef.field === headerName) {
  //     cellStyle["background-color"] = 'red'; // Your desired color for editing
  //   }
  
  //   return cellStyle;
  // }
  
  getCellStyle(params: any, headerName: string) {
    let cellStyle: any = { "background-color": params.node.rowPinned ? 'inherit' : this.bgColor[headerName] };
    
    if (params.node.data.editing && params.colDef.field === headerName) {
      cellStyle["background-color"] = '#ffcc00'; // Your desired color for editing
      
    }


    // if (params.node.id === params.data.editingCellId && params.colDef.field === headerName) {
    //   cellStyle["background-color"] = '#ffcc00'; // Your desired color for editing
    // }
  
    return cellStyle;
  }
  
  

}
