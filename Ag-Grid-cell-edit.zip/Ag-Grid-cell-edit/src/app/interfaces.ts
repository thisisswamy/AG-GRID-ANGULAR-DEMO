export interface IOlympicData {
    id: number,
    name: string,
    amount: string,
   
}